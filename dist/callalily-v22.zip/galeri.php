<?php
/**
 * Galeri pesta. Bola 3D-nya tidak diubah sama sekali — hanya sumber datanya
 * yang pindah dari array hardcoded ke tabel `gallery`, sehingga owner bisa
 * menambah foto lewat panel tanpa menyentuh berkas ini.
 */
require_once __DIR__ . '/inc/bootstrap.php';

$rows = all("SELECT slug, media_type, video_file, who, caption, alt_text
             FROM gallery WHERE is_published = 1
             ORDER BY sort_order ASC, id ASC");

$photos = array_map(fn($r) => array_filter([
    'file'  => $r['slug'],
    'who'   => $r['who'],
    'cap'   => $r['caption'],
    'alt'   => $r['alt_text'],
    'video' => $r['media_type'] === 'video' ? $r['video_file'] : null,
], fn($v) => $v !== null), $rows);

// Data terstruktur ImageGallery supaya foto bisa muncul di Google Images.
$ld = [
    '@context' => 'https://schema.org',
    '@type'    => 'ImageGallery',
    'name'     => 'Galeri pesta ' . setting('site_name', 'Callalily Party'),
    'url'      => url('galeri'),
    'associatedMedia' => array_slice(array_map(fn($r) => [
        '@type'       => $r['media_type'] === 'video' ? 'VideoObject' : 'ImageObject',
        'contentUrl'  => $r['media_type'] === 'video' ? url('video/' . $r['video_file']) : url('foto/' . $r['slug'] . '.jpg'),
        'thumbnailUrl'=> url('foto/' . $r['slug'] . '-thumb.jpg'),
        'name'        => $r['who'],
        'description' => $r['alt_text'] ?: ($r['who'] . ' — ' . $r['caption']),
    ], $rows), 0, 30),
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?= seoHead([
  'title' => 'Galeri Pesta — ' . setting('site_name', 'Callalily Party') . ' Wedding Organizer Yogyakarta',
  'desc'  => 'Portofolio pesta pernikahan yang ditangani ' . setting('site_name', 'Callalily Party') . ', wedding organizer Yogyakarta — ' . count($photos) . ' momen foto dan video dalam satu bola yang bisa diputar.',
  'canonical' => url('galeri'),
  'image' => $photos ? url('foto/' . $photos[0]['file'] . '.jpg') : null,
  'jsonld' => [ldOrganization(), $ld, ldBreadcrumb([
      ['Beranda', url()], ['Galeri pesta', url('galeri')],
  ])],
]) ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,400..700;1,6..96,400..700&family=Hanken+Grotesk:ital,wght@0,300..700;1,300..700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --ivory:#F1EAD9;
  --ivory-60:rgba(241,234,217,.6);
  --ivory-30:rgba(241,234,217,.3);
  --ivory-12:rgba(241,234,217,.12);
  --ink:#17181A;
  --ember:#E9A85C;
  --ember-deep:#C97F3B;
  --serif:"Bodoni Moda","Didot",serif;
  --sans:"Hanken Grotesk",system-ui,sans-serif;
  --mono:"IBM Plex Mono",ui-monospace,monospace;
  --pad:clamp(18px,4vw,54px);
}
*{margin:0;padding:0;box-sizing:border-box}
html{overflow-x:clip;scroll-behavior:smooth}
::selection{background:var(--ember);color:var(--ink)}
::-webkit-scrollbar{width:9px}
::-webkit-scrollbar-track{background:#05070F}
::-webkit-scrollbar-thumb{background:#2A2F45;border-radius:99px}
body{
  font-family:var(--sans);color:var(--ivory);background:var(--ink);
  line-height:1.6;-webkit-font-smoothing:antialiased;overflow-x:clip;
}
a{color:inherit}
button{font:inherit;cursor:pointer;color:inherit;background:none;border:none}
:focus-visible{outline:2px solid var(--ember);outline-offset:3px;border-radius:6px}

/* ================= LATAR ================= */
.bg{position:fixed;inset:0;z-index:0;overflow:hidden;
  background:
    radial-gradient(120% 92% at 50% 116%, #48283f 0%, transparent 56%),
    radial-gradient(88% 68% at 80% 6%, #272052 0%, transparent 60%),
    linear-gradient(168deg,#060812 0%,#0d0b1e 48%,#161022 100%);
}
.bg::before{content:"";position:absolute;left:50%;top:46%;
  width:min(150vw,1400px);height:min(150vw,1400px);transform:translate(-50%,-50%);
  border-radius:50%;pointer-events:none;filter:blur(16px);
  background:radial-gradient(circle,rgba(233,168,92,.17) 0%,rgba(176,86,126,.09) 36%,transparent 68%);}
.bokeh{position:absolute;inset:0;pointer-events:none}
.bokeh i{position:absolute;border-radius:50%;
  background:radial-gradient(circle,var(--c,#FFE9C4),transparent 66%);
  filter:blur(1px);animation:float var(--d,22s) ease-in-out infinite alternate}
@keyframes float{from{transform:translate(0,0)}to{transform:translate(var(--mx,20px),var(--my,-28px))}}
.vignette{position:fixed;inset:0;z-index:2;pointer-events:none;
  background:radial-gradient(ellipse at center,transparent 46%,rgba(3,5,12,.7) 100%)}

/* ================= NAV ================= */
nav{position:fixed;inset:0 0 auto 0;z-index:50;
  display:flex;justify-content:space-between;align-items:center;
  padding:18px var(--pad);
  background:linear-gradient(to bottom,rgba(6,8,18,.72),transparent);}
.brand{font-family:var(--serif);font-style:italic;font-weight:500;font-size:clamp(19px,2.4vw,24px);
  letter-spacing:.04em;text-decoration:none;text-shadow:0 2px 24px rgba(0,0,0,.7)}
.brand sup{font-family:var(--mono);font-size:8.5px;font-style:normal;letter-spacing:.16em;
  color:var(--ember);margin-left:7px;vertical-align:super;white-space:nowrap}
@media(max-width:620px){.brand sup{display:none}}
.navr{display:flex;align-items:center;gap:clamp(10px,2vw,20px)}
.navlink{font-family:var(--mono);font-size:10.5px;font-weight:500;letter-spacing:.22em;
  text-transform:uppercase;color:var(--ivory-60);text-decoration:none;transition:color .2s ease}
.navlink:hover{color:var(--ember)}
@media(max-width:620px){.navlink{display:none}}
.btn{display:inline-flex;align-items:center;gap:9px;border:1px solid var(--ivory-30);
  border-radius:999px;background:rgba(7,10,22,.6);padding:10px 20px;font-size:13px;
  font-weight:600;letter-spacing:.02em;text-decoration:none;transition:all .25s ease}
.btn:hover{border-color:var(--ember);color:var(--ember);transform:translateY(-1px)}
.btn.solid{background:var(--ember);border-color:var(--ember);color:var(--ink)}
.btn.solid:hover{background:var(--ember-deep);border-color:var(--ember-deep);color:var(--ink)}

/* ================= PANGGUNG LAYAR PENUH ================= */
.stage{
  position:relative;z-index:5;
  height:100vh;height:100svh;
  width:100%;
  display:grid;place-items:center;
  overflow:hidden;
  touch-action:none;user-select:none;-webkit-user-select:none;
  cursor:grab;
}
.stage.grabbing{cursor:grabbing}
.sphere{position:relative;z-index:5;width:0;height:0;transform-style:preserve-3d;
  will-change:transform;opacity:0;transition:opacity .9s ease}
/* bola cahaya: membuat volumenya terbaca walau kepingnya masih sedikit */
.orb{position:absolute;z-index:3;left:50%;top:50%;border-radius:50%;pointer-events:none;
  transform:translate(-50%,-50%);opacity:0;transition:opacity 1.1s ease;
  border:1px solid rgba(241,234,217,.08);
  background:
    radial-gradient(circle at 36% 30%, rgba(233,168,92,.13), transparent 58%),
    radial-gradient(circle at 68% 74%, rgba(176,86,126,.11), transparent 62%),
    radial-gradient(circle, rgba(255,233,196,.05) 0%, rgba(12,11,23,.28) 72%, transparent 100%);
  box-shadow:inset 0 0 150px rgba(233,168,92,.09), 0 0 120px rgba(233,168,92,.07);}
.orb.ready{opacity:1}
.sphere.ready{opacity:1}

.tile{
  position:absolute;width:var(--tw,170px);height:var(--th,218px);
  margin-top:calc(var(--th,218px) / -2);margin-left:calc(var(--tw,170px) / -2);
  border-radius:14px;overflow:hidden;padding:0;
  border:1px solid rgba(241,234,217,.16);
  background:linear-gradient(158deg,#2a1838,#0c0b17);
  backface-visibility:hidden;
  box-shadow:0 26px 60px -24px rgba(0,0,0,.9), inset 0 0 0 1px rgba(255,255,255,.04);
  will-change:opacity,filter;
}
.tile img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;
  transition:transform .4s ease}
.tile:hover img{transform:scale(1.06)}
/* gambar gagal dimuat -> jangan tampilkan ikon rusak, cukup panel warna */
.tile img.err{opacity:0}
.tile .fallback{position:absolute;inset:0;display:none;place-items:center;
  font-family:var(--mono);font-size:9px;letter-spacing:.2em;text-transform:uppercase;
  color:var(--ivory-30);text-align:center;padding:10px}
.tile img.err ~ .fallback{display:grid}

/* lencana video */
.tile .play{position:absolute;top:9px;right:9px;width:28px;height:28px;border-radius:50%;
  background:rgba(7,10,22,.6);border:1px solid rgba(241,234,217,.5);backdrop-filter:blur(4px)}
.tile .play::after{content:"";position:absolute;top:50%;left:54%;transform:translate(-50%,-50%);
  border-style:solid;border-width:5px 0 5px 8.5px;
  border-color:transparent transparent transparent var(--ivory)}

/* keterangan hanya saat disorot — bola tetap bersih */
.tile .cap{position:absolute;left:0;right:0;bottom:0;padding:40px 12px 11px;
  opacity:0;transition:opacity .25s ease;pointer-events:none;
  background:linear-gradient(to top,rgba(3,5,12,.96) 0%,rgba(3,5,12,.72) 45%,transparent 100%)}
.tile:hover .cap{opacity:1}
.tile .cap b{display:block;font-family:var(--mono);font-size:9px;letter-spacing:.18em;
  color:var(--ember);font-weight:500}
.tile .cap span{display:block;font-size:11.5px;line-height:1.32;margin-top:3px;color:var(--ivory)}

/* ---- lapisan tulisan di atas panggung ---- */
.veil{position:absolute;inset:0;z-index:8;pointer-events:none;
  display:flex;flex-direction:column;justify-content:space-between;
  padding:clamp(80px,11vh,112px) var(--pad) clamp(18px,3.5vh,30px)}
.veil > *{pointer-events:none}
.veil button,.veil a{pointer-events:auto}
/* sudut adalah ruang kosong di sekitar bola — tulisan ditaruh di situ */
.vtop{max-width:min(26ch,40vw)}
@media(max-width:720px){.vtop{max-width:22ch}}
.eyebrow{font-family:var(--mono);font-size:10.5px;font-weight:600;letter-spacing:.32em;
  text-transform:uppercase;color:var(--ember);display:block;margin-bottom:10px;
  text-shadow:0 2px 16px rgba(0,0,0,.9)}
.vtop h1{font-family:var(--serif);font-weight:400;line-height:1.05;
  font-size:clamp(1.5rem,3.1vw,2.5rem);letter-spacing:.005em;
  text-shadow:0 4px 30px rgba(0,0,0,.9),0 2px 10px rgba(0,0,0,.7)}
.vtop h1 em{font-style:italic;color:var(--ember)}

.vbot{display:flex;align-items:center;gap:14px;flex-wrap:wrap}
@media(max-width:720px){.vbot{justify-content:center;text-align:center}}
.readout{font-family:var(--mono);font-size:10.5px;letter-spacing:.2em;text-transform:uppercase;
  color:var(--ivory-60);text-shadow:0 2px 14px rgba(0,0,0,.9);min-height:1.2em;
  transition:color .2s ease}
.readout b{color:var(--ember);font-weight:500}
.readout.hot{color:var(--ivory)}
.spin-toggle{border:1px solid var(--ivory-12);border-radius:999px;
  background:rgba(7,10,22,.62);padding:6px 14px;font-family:var(--mono);font-size:9.5px;
  letter-spacing:.16em;text-transform:uppercase;color:var(--ivory-60);transition:all .2s ease;
  backdrop-filter:blur(4px)}
.spin-toggle:hover{border-color:var(--ember);color:var(--ember)}

/* petunjuk gulir */
.scrollcue{position:absolute;right:var(--pad);bottom:clamp(18px,3.5vh,30px);
  z-index:6;pointer-events:none;display:flex;flex-direction:column;align-items:center;gap:8px;
  font-family:var(--mono);font-size:9px;letter-spacing:.3em;text-transform:uppercase;
  color:var(--ivory-30)}
.scrollcue i{width:1px;height:34px;display:block;
  background:linear-gradient(var(--ember),transparent);animation:drip 2.4s ease-in-out infinite}
@keyframes drip{0%{transform:scaleY(0);transform-origin:top}55%{transform:scaleY(1);transform-origin:top}
  56%{transform-origin:bottom}100%{transform:scaleY(0);transform-origin:bottom}}
@media(max-height:620px){.scrollcue{display:none}}

/* pemuat */
.loader{position:absolute;inset:0;z-index:7;display:grid;place-items:center;pointer-events:none;
  font-family:var(--mono);font-size:10px;letter-spacing:.3em;text-transform:uppercase;
  color:var(--ivory-30);transition:opacity .5s ease}
.loader.off{opacity:0}

/* ================= PENUTUP ================= */
.cta{position:relative;z-index:5;text-align:center;padding:clamp(64px,12vh,130px) var(--pad) 46px}
.cta h2{font-family:var(--serif);font-weight:400;font-size:clamp(1.7rem,3.8vw,2.9rem);
  line-height:1.1;margin-bottom:14px;max-width:20ch;margin-inline:auto}
.cta h2 em{font-style:italic;color:var(--ember)}
.cta p{color:var(--ivory-60);font-weight:300;max-width:48ch;margin:0 auto 28px;
  font-size:clamp(14px,1.3vw,16px)}
.cta-row{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
footer{position:relative;z-index:5;padding:24px var(--pad);
  display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;
  font-family:var(--mono);font-size:10px;letter-spacing:.1em;color:var(--ivory-30);
  border-top:1px solid var(--ivory-12);background:rgba(4,6,14,.5)}

/* ================= LIGHTBOX ================= */
.lb{position:fixed;inset:0;z-index:90;display:none;place-items:center;
  background:rgba(3,5,12,.94);backdrop-filter:blur(16px);
  padding:clamp(58px,8vw,92px) clamp(14px,5vw,80px)}
.lb.on{display:grid}
.lb-fig{max-width:min(1060px,100%);display:flex;flex-direction:column;gap:16px}
.lb-media{border:1px solid var(--ivory-12);border-radius:14px;overflow:hidden;
  background:#000;display:grid;place-items:center}
.lb-media img,.lb-media video{max-width:100%;max-height:min(72vh,860px);display:block;
  object-fit:contain;background:#000}
.lb-media video{width:auto}
.lb-cap{display:flex;gap:20px;align-items:baseline;flex-wrap:wrap;justify-content:space-between}
.lb-cap .who{font-family:var(--mono);font-size:11px;letter-spacing:.26em;color:var(--ember);
  text-transform:uppercase}
.lb-cap .cx{font-family:var(--serif);font-style:italic;font-size:clamp(1rem,2.1vw,1.45rem);flex:1}
.lb-cap .cnt{font-family:var(--mono);font-size:11px;color:var(--ivory-30);letter-spacing:.16em}
.lb-close,.lb-nav{position:fixed;width:46px;height:46px;border-radius:999px;
  border:1px solid var(--ivory-30);background:rgba(7,10,22,.75);display:grid;place-items:center;
  font-size:19px;line-height:1;backdrop-filter:blur(6px);transition:all .2s ease}
.lb-close{top:20px;right:20px}
.lb-nav.prev{left:20px;top:50%;transform:translateY(-50%)}
.lb-nav.next{right:20px;top:50%;transform:translateY(-50%)}
.lb-close:hover,.lb-nav:hover{border-color:var(--ember);color:var(--ember)}
@media(max-width:640px){
  .lb-nav{top:auto;bottom:22px;transform:none}
  .lb-nav.prev{left:22px}.lb-nav.next{right:22px}
}

@media (prefers-reduced-motion: reduce){
  html{scroll-behavior:auto}
  .bokeh i,.bg::before,.scrollcue i{animation:none}
  .tile:hover img{transform:none}
}
</style>
</head>
<body>

<div class="bg" aria-hidden="true"><div class="bokeh" id="bokeh"></div></div>
<div class="vignette" aria-hidden="true"></div>

<nav>
  <a class="brand" href="<?= url() ?>">Callalily<sup>PARTY · WEDDING ORGANIZER</sup></a>
  <div class="navr">
    <a class="navlink" href="<?= url() ?>">← Beranda</a>
    <a class="btn solid" href="<?= url() ?>#susun">Susun harimu</a>
  </div>
</nav>

<main class="stage" id="stage">
  <div class="orb" id="orb" aria-hidden="true"></div>
  <div class="sphere" id="sphere"></div>

  <div class="veil">
    <div class="vtop">
      <span class="eyebrow">Portofolio pesta</span>
      <h1>Satu bola cahaya, <em>berisi banyak malam.</em></h1>
    </div>
    <div class="vbot">
      <span class="readout" id="readout"></span>
      <button class="spin-toggle" id="spinToggle" type="button" aria-pressed="true">Putar otomatis: on</button>
    </div>
  </div>

  <div class="scrollcue" aria-hidden="true"><span>Gulir</span><i></i></div>
  <div class="loader" id="loader">Memuat momen…</div>
</main>

<section class="cta">
  <h2>Bolanya berhenti di sini. <em>Pestamu belum.</em></h2>
  <p>Susun rundown harimu sendiri di beranda, kirim drafnya, penawaran kami hitung khusus untuk susunan itu.</p>
  <div class="cta-row">
    <a class="btn solid" href="<?= url() ?>#susun">Susun harimu</a>
    <a class="btn" href="<?= url() ?>#tanya">Tanya jawab</a>
  </div>
</section>

<footer>
  <span>CALLALILY PARTY WEDDING ORGANIZER · Yogyakarta</span>
  <span>© 2026 · dokumentasi milik klien Callalily</span>
</footer>

<div class="lb" id="lb" role="dialog" aria-modal="true" aria-label="Pratinjau" hidden>
  <button class="lb-close" id="lbClose" type="button" aria-label="Tutup">✕</button>
  <button class="lb-nav prev" id="lbPrev" type="button" aria-label="Sebelumnya">‹</button>
  <button class="lb-nav next" id="lbNext" type="button" aria-label="Berikutnya">›</button>
  <figure class="lb-fig">
    <div class="lb-media" id="lbMedia"></div>
    <figcaption class="lb-cap">
      <span class="who" id="lbWho"></span>
      <span class="cx" id="lbCap"></span>
      <span class="cnt" id="lbCnt"></span>
    </figcaption>
  </figure>
</div>

<script>
"use strict";
const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
const $ = id => document.getElementById(id);

/* =====================================================
   DATA GALERI
   file  : nama berkas TANPA ekstensi, di folder foto/
           dimuat sebagai  foto/<file>-thumb.jpg  (keping bola)
           dan             foto/<file>.jpg        (saat diperbesar)
   video : diisi hanya bila item ini video (berkas ada di folder video/)

   MENAMBAH FOTO: cukup tambah satu baris di sini, lalu unggah
   dua berkasnya ke folder foto/. Ukuran bola menyesuaikan sendiri.
===================================================== */
const PHOTOS = <?= ejs($photos) ?>;
const N = PHOTOS.length;

/* =====================================================
   BOLA — CSS 3D murni, tanpa pustaka luar.
   Keping disebar dengan deret Fibonacci (paling merata di
   permukaan bola), masing-masing menghadap keluar. Yang diputar
   adalah wadahnya; tiap frame kita hitung seberapa "menghadap
   kamera" tiap keping untuk mengatur terang-gelap dan klik.
===================================================== */
const sphere = $("sphere"), stage = $("stage"), readout = $("readout");
const GOLDEN = Math.PI * (3 - Math.sqrt(5));
const RAD = Math.PI/180;
let R = 340;
const tiles = [];

const DEFAULT_READOUT = `<b>${N}</b> momen · tarik untuk memutar · klik untuk memperbesar`;
readout.innerHTML = DEFAULT_READOUT;

function build(){
  sphere.innerHTML=""; tiles.length=0;

  const mobile = innerWidth < 720;
  const S = Math.min(innerWidth, stage.clientHeight || innerHeight);
  /* kerapatan menyesuaikan jumlah keping: makin banyak foto, kepingnya
     mengecil — bolanya tetap sebesar layar, tidak ikut menyusut */
  const dens = Math.max(.6, Math.min(1.3, Math.sqrt(14/N)));
  const tw = Math.round(S * (mobile ? .26 : .19) * dens);
  const th = Math.round(tw * 1.28);

  /* Radius diambil sebesar mungkin. Perspektif memendekkan bagian kutub,
     jadi bola boleh lebih besar dari setengah layar tanpa terpotong:
     jari-jari di layar = R × P/(P+R), bukan R. */
  const P = Math.round(S * (mobile ? 1.7 : 1.55));
  R = Math.round(S * (mobile ? .54 : .58));

  sphere.style.setProperty("--tw", tw+"px");
  sphere.style.setProperty("--th", th+"px");
  stage.style.perspective = P + "px";

  /* bola cahaya dibuat sebesar siluet bola yang sebenarnya terlihat */
  const rLayar = R * P/(P+R);
  const orb = $("orb");
  orb.style.width = orb.style.height = Math.round(rLayar*2) + "px";

  PHOTOS.forEach((p,i)=>{
    const y = 1 - (i/(N-1))*2;
    const rr = Math.sqrt(Math.max(0,1-y*y));
    const t2 = i*GOLDEN;
    const x = Math.cos(t2)*rr, z = Math.sin(t2)*rr;
    const lon = Math.atan2(x,z)/RAD, lat = -Math.asin(y)/RAD;

    const el = document.createElement("button");
    el.type="button"; el.className="tile"; el.dataset.i=i;
    el.style.transform = `rotateY(${lon}deg) rotateX(${lat}deg) translateZ(${R}px)`;
    el.innerHTML =
      `<img src="foto/${p.file}-thumb.jpg" alt="${p.alt || (p.who + " — " + p.cap)}" decoding="async" loading="lazy">` +
      `<span class="fallback">${p.who}</span>` +
      (p.video ? `<span class="play" aria-hidden="true"></span>` : "") +
      `<span class="cap"><b>${p.who}</b><span>${p.cap}</span></span>`;
    el.setAttribute("aria-label",(p.video?"Putar video: ":"Perbesar: ")+p.who+" — "+p.cap);

    /* berkas foto belum diunggah / folder terpisah dari HTML:
       tampilkan panel warna, bukan ikon gambar rusak */
    const img = el.querySelector("img");
    img.addEventListener("error", ()=>img.classList.add("err"));

    el.addEventListener("mouseenter", ()=>{
      readout.innerHTML = `<b>${p.who}</b> · ${p.cap}`;
      readout.classList.add("hot");
    });
    el.addEventListener("mouseleave", ()=>{
      readout.innerHTML = DEFAULT_READOUT;
      readout.classList.remove("hot");
    });

    sphere.appendChild(el);
    tiles.push({el, d:[x,y,z]});
  });
}
build();

/* tampilkan bola begitu gambar selesai (atau setelah 2,5 dtk) */
(function(){
  const imgs=[...document.querySelectorAll(".tile img")];
  let left=imgs.length;
  const done=()=>{ if(--left<=0) reveal(); };
  function reveal(){
    sphere.classList.add("ready");
    $("orb").classList.add("ready");
    $("loader").classList.add("off");
  }
  imgs.forEach(im=>{
    if(im.complete) done();
    else { im.addEventListener("load",done,{once:true});
           im.addEventListener("error",done,{once:true}); }
  });
  setTimeout(reveal, 2500);
})();

/* ---------- putaran: otomatis + tarik + inersia ---------- */
let gx = -8, gy = 0;
let vx = 0, vy = reduced ? 0 : 0.26;
const IDLE = reduced ? 0 : 0.26;          /* ~23 detik sekali putar */
let autoSpin = !reduced;
let dragging=false, moved=0, lastX=0, lastY=0, downTile=null;

function facingOf(d){
  const gxr=gx*RAD, gyr=gy*RAD;
  const cx=Math.cos(gxr), sx=Math.sin(gxr), cy=Math.cos(gyr), sy=Math.sin(gyr);
  const x1 =  d[0]*cy + d[2]*sy;
  const z1 = -d[0]*sy + d[2]*cy;
  return d[1]*sx + z1*cx;
}

function frame(){
  if(!dragging){
    if(autoSpin) vy += (IDLE - vy)*0.03;
    gy += vy; gx += vx; vx *= 0.92;
    if(gx> 74){gx= 74; vx=0;}
    if(gx<-74){gx=-74; vx=0;}
  }
  sphere.style.transform = `translateZ(-${R}px) rotateX(${gx}deg) rotateY(${gy}deg)`;
  for(const tl of tiles){
    const f = facingOf(tl.d);
    tl.el.style.opacity = Math.max(0, Math.min(1, f*1.2 + 0.14)).toFixed(3);
    tl.el.style.filter = `brightness(${(0.5 + 0.5*Math.max(0,f)).toFixed(3)})`;
    tl.el.style.pointerEvents = f > 0.2 ? "auto" : "none";
    tl.el.style.zIndex = Math.round((f+1)*500);
  }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

stage.addEventListener("pointerdown", e=>{
  dragging=true; moved=0; lastX=e.clientX; lastY=e.clientY;
  downTile = e.target.closest(".tile");
  vx=vy=0; stage.classList.add("grabbing");
  stage.setPointerCapture(e.pointerId);
});
stage.addEventListener("pointermove", e=>{
  if(!dragging) return;
  const dx=e.clientX-lastX, dy=e.clientY-lastY;
  lastX=e.clientX; lastY=e.clientY;
  moved += Math.abs(dx)+Math.abs(dy);
  gy += dx*0.28; gx -= dy*0.28;
  if(gx>74)gx=74; if(gx<-74)gx=-74;
  vy = dx*0.28; vx = -dy*0.28;
});
function endDrag(){
  if(!dragging) return;
  dragging=false; stage.classList.remove("grabbing");
  if(moved < 7 && downTile && downTile.style.pointerEvents!=="none"){
    lbShow(+downTile.dataset.i); vy=0;
  }
}
stage.addEventListener("pointerup", endDrag);
stage.addEventListener("pointercancel", endDrag);

const spinToggle = $("spinToggle");
spinToggle.addEventListener("click", ()=>{
  autoSpin = !autoSpin;
  if(!autoSpin) vy = 0;
  spinToggle.textContent = "Putar otomatis: " + (autoSpin?"on":"off");
  spinToggle.setAttribute("aria-pressed", autoSpin);
});
if(reduced){ spinToggle.textContent="Putar otomatis: off"; spinToggle.setAttribute("aria-pressed","false"); }

sphere.addEventListener("keydown", e=>{
  const t=e.target.closest(".tile");
  if(t && (e.key==="Enter"||e.key===" ")){ e.preventDefault(); lbShow(+t.dataset.i); }
});

/* ---------- lightbox ---------- */
const lb=$("lb"), lbMedia=$("lbMedia"), lbWho=$("lbWho"), lbCap=$("lbCap"), lbCnt=$("lbCnt");
let lbIdx=0, lastFocus=null;
function lbShow(i){
  lbIdx=i; const p=PHOTOS[i];
  lbMedia.innerHTML = p.video
    ? `<video src="video/${p.video}" poster="foto/${p.file}.jpg" controls autoplay playsinline
              preload="metadata" aria-label="${p.who} — ${p.cap}"></video>`
    : `<img src="foto/${p.file}.jpg" alt="${p.alt || (p.who + " — " + p.cap)}">`;
  lbWho.textContent=p.who; lbCap.textContent=p.cap; lbCnt.textContent=(i+1)+" / "+N;
  if(!lb.classList.contains("on")){
    lastFocus=document.activeElement;
    lb.hidden=false; lb.classList.add("on");
    document.documentElement.style.overflow="hidden";
    $("lbClose").focus();
  }
}
function stopVideo(){
  const v=lbMedia.querySelector("video");
  if(v){ v.pause(); v.removeAttribute("src"); v.load(); }
}
function lbStep(d){ stopVideo(); lbShow((lbIdx+d+N)%N); }
function lbHide(){
  stopVideo();
  lb.classList.remove("on"); lb.hidden=true;
  document.documentElement.style.overflow="";
  if(lastFocus)lastFocus.focus();
}
$("lbClose").onclick=lbHide;
$("lbPrev").onclick=()=>lbStep(-1);
$("lbNext").onclick=()=>lbStep(1);
lb.addEventListener("click", e=>{ if(e.target===lb) lbHide(); });
addEventListener("keydown", e=>{
  if(!lb.classList.contains("on")) return;
  if(e.key==="Escape") lbHide();
  else if(e.key==="ArrowRight") lbStep(1);
  else if(e.key==="ArrowLeft") lbStep(-1);
});

/* ---------- bokeh ---------- */
(function(){
  const box=$("bokeh"), cols=["#FFE9C4","#E9A85C","#B0567E","#EAC08A"];
  const n = innerWidth<720 ? 10 : 20;
  for(let i=0;i<n;i++){
    const b=document.createElement("i");
    const s=6+Math.random()*24;
    b.style.width=b.style.height=s+"px";
    b.style.left=(4+Math.random()*88)+"%";
    b.style.top=(Math.random()*100)+"%";
    b.style.setProperty("--c",cols[i%cols.length]);
    b.style.setProperty("--d",(16+Math.random()*16)+"s");
    b.style.setProperty("--mx",(Math.random()*60-30)+"px");
    b.style.setProperty("--my",(Math.random()*60-30)+"px");
    b.style.opacity=(0.22+Math.random()*0.38).toFixed(2);
    b.style.animationDelay=(-Math.random()*16)+"s";
    box.appendChild(b);
  }
})();

let rz; addEventListener("resize", ()=>{ clearTimeout(rz); rz=setTimeout(()=>{ build(); sphere.classList.add("ready"); $("orb").classList.add("ready"); }, 200); });
</script>

<?php if ($ga = setting('ga_measurement_id')): ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($ga) ?>"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','<?= e($ga) ?>');</script>
<?php endif; ?>
</body>
</html>
